#include "ant.h"

extern Control * gc;

void keyBoardControl(unsigned char key, int x, int y){
	if (key == 'f' || key == 'F'){
		printMatrix(gc->matrix);
		printf("\n");
	}
	if (key == 'p' || key == 'P'){
		if(!gc->pause){
			fpsControl(0);
		}
		gc->pause = !gc->pause;
	}
	if (key == 'c' || key == 'C'){
		pthread_mutex_lock(&(gc->matrix->mutexMatrix));
		int espacosLivres = 0, qtdFormigas = 0, qtdMortas = 0;
		for (int i = 0; i < ROWS; i++){
			for (int j = 0; j < COLS; j++){
				DeadAnt * celula = gc->matrix->data[i][j];
				if (celula == NULL)
					espacosLivres++;
				else
					qtdMortas++;
			}
		}

		printf("---------------Dados na Matrix---------------\nEspaços Livres: %i / %i\nQtd Formigas: %i / %i\nQtd Mortas: %i / %i\n",
			espacosLivres, (ROWS * COLS), qtdFormigas, ANT, qtdMortas, gc->numDeadAnt);
		pthread_mutex_unlock(&(gc->matrix->mutexMatrix));
	}
}
