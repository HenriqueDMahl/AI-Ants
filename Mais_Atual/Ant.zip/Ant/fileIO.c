#include "ant.h"

#define INT        "[+-]?[0-9]+"
#define FLOAT      "[+-]?[0-9]+\\.?[0-9]*"
#define FIRST_LINE "#N=("INT"), k=("INT"), D=("INT")"
#define OTHER_LINE "("FLOAT")\t("FLOAT")\t("INT")"



extern Control * gc;

int readLine(FILE * file, char ** line){
	char c;
	int size = 10, size_v = 10, num = 0;

	if (*line != NULL){
		free(*line);
		*line = NULL;
	}

	*line = (char *) malloc(sizeof(char) * size_v);
	if (*line == NULL){
		return -1;	
	}
	memset(*line, '\0', size_v);
	while (1){
		num++;
		c = fgetc(file);
		if (feof(file)){
			return 1;
		}else if (c == '\n'){
			return 0;
		}

		if (num > size){
			size+=size_v;
			char * tmp = realloc(*line, sizeof(char) * size);
			if (tmp==NULL)
				return -1;
			*line = tmp;

			memset((*line)+ size-size_v, '\0', size_v);
		}

		line[0][num-1] = c;
	}

	return 2;
}

void rlnError(int code){
	if (!code)
		printf("It was a SUCESS! No error\n");
	else if (code == 1)
		printf("Just The End of File\n");
	else if (code == -1)
		printf("Erro de alocacao de memoria para a variavel 'line'\n");
	else if (code == 2)
		printf("Nao sei como chegou aqui. Seu computador esta bugado.\n");
}

int match(char * fmt, char * str, int nElem, char *** elem){
	regex_t reg;
	regmatch_t * ret = (regmatch_t *) malloc(sizeof(regmatch_t) * nElem);
	if (ret == NULL){printf("Erro em alocacao de memoria de regmatch_t\n"); exit(-6);}
	int resp;
	resp = regcomp(&reg, fmt, REG_EXTENDED);
	if (resp != 0){
		printf("Erro ao compilar regex: %i\n", resp);
		exit(-6);
	}

	resp = regexec(&reg, str, nElem, ret, 0);
	regfree(&reg);

	if (resp != 0){
		return 0;
	} else if (nElem <= 0){
		return 1;
	}

	elem[0] = (char **) malloc(sizeof(char *) * nElem);
	if (elem[0] == NULL) {printf("Erro em alocacao de memoria - (regex)\n");exit(-6);}
	for (int i = 0; i < nElem; i++){
		if (ret[i].rm_so == -1)
			return 0;

		int len = ret[i].rm_eo - ret[i].rm_so;

		elem[0][i] = (char *) malloc(sizeof(char) * (len+1));
		if (elem[0][i] == NULL) {printf("[%i]: Erro em alocacao de memoria (regex) (%i)\n", i, len+1);exit(-6);}

		memcpy(elem[0][i], str + ret[i].rm_so, len);
		elem[0][i][len] = '\0';

	}

	return 1;
}


DeadAnt * loadFromFile(Group * g, char * filename){
	//Carrega todos os itens a partir da file, se existir
	FILE * file = fopen(filename, "r");
	DeadAnt * d = NULL;
	if (file == NULL)
		return NULL;

	char * line = NULL;
	int n = 0;
	while (!readLine(file, &line)){
		char **ret = NULL;

		if (match(FIRST_LINE, line, 4, &ret)){
			d = malloc(sizeof(DeadAnt) * atoi(ret[1]));
			gc->numGroups = atoi(ret[2]);
			gc->numParameters = atoi(ret[3]);
		}else if (match(OTHER_LINE, line, gc->numParameters+2, &ret)){
			newDeadAnt(g, &d[n]);

			d[n].parameters = malloc(sizeof(float) * gc->numParameters);
			if (d[n].parameters == NULL)
				return NULL;

			for (int i = 0; i < gc->numParameters; i++)
				d[n].parameters[i] = atof(ret[i+1]);

			d[n].grupo = atoi(ret[gc->numParameters+1]);
			switch (d[n].grupo){
				case 1:
					d[n].imagem->setColor(d[n].imagem, 0 ,0 ,0 , 1);
				break;
				case 2:
					d[n].imagem->setColor(d[n].imagem, 1 ,0 ,0 , 1);
				break;
				case 3:
					d[n].imagem->setColor(d[n].imagem, 0 ,1 ,0 , 1);
				break;
				case 4:
					d[n].imagem->setColor(d[n].imagem, 0 ,0 ,1 , 1);
				break;
				case 5:
					d[n].imagem->setColor(d[n].imagem, 1 ,0 ,1 , 1);
				break;
				case 6:
					d[n].imagem->setColor(d[n].imagem, 1 ,1 ,0 , 1);
				break;
				case 7:
					d[n].imagem->setColor(d[n].imagem, 0 ,1 ,1 , 1);
				break;
				case 8:
					d[n].imagem->setColor(d[n].imagem, 1 ,1 ,1 , 1);
				break;
				case 9:
					d[n].imagem->setColor(d[n].imagem, 1 ,0.5 ,0.25 , 1);
				break;
				case 10:
					d[n].imagem->setColor(d[n].imagem, 0.5 ,0.5 ,0.25 , 1);
				break;
				case 11:
					d[n].imagem->setColor(d[n].imagem, 0.75 ,1 ,0.25 , 1);
				break;
				case 12:
					d[n].imagem->setColor(d[n].imagem, 1 ,0.5 ,1 , 1);
				break;
				case 13:
					d[n].imagem->setColor(d[n].imagem, 0.6 ,0.3 ,0.25 , 1);
				break;
				case 14:
					d[n].imagem->setColor(d[n].imagem, 0 ,0.5 ,1 , 1);
				break;
				case 15:
					d[n].imagem->setColor(d[n].imagem, 0.5 ,0.25 ,1 , 1);
				break;
			}


			n++;
		}

	}



	fclose(file);
	file = NULL;

	return d;
}





