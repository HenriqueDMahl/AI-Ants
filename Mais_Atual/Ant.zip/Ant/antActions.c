#include "ant.h"

extern Control * gc;


/*

    Erros que observei:
      --> Algumas formigas conseguem pegar itens das outras formigas, mesmo que ja
      estejam carregando...

*/

float dist(DeadAnt * d1, DeadAnt * d2){
	return sqrt(pow(d1->i - d2->i, 2) + pow(d1->j - d2->j, 2));
}

float contarEmVolta(int x, int y, int radius, DeadAnt * middle){
  Matrix * m = gc->matrix;
  float f = 0;
  

  int cont = 0;
  float alpha_mult = 10;      //<------



  float max = (radius*2 + 1)*(radius*2 + 1) - 1;
  float alpha = ALPHA;
  for (int i = x-radius; i <= x+radius; i++){
    for (int j = y-radius; j <= y+radius; j++){
      //Condicional para nao sair dos limites da matrix
      if (i >= 0 && j >= 0 && i < m->rows && j < m->cols && !(i == x && j == y)){
      	if (m->data[i][j] != NULL){
      		if(m->data[i][j]->grupo == middle->grupo)
      			//cont++;
            alpha *= alpha_mult;
	      }
      }

    }
  }
  // if(cont >= 5){
  // 	alpha = 0.01;
  // }else{
  // 	alpha = 100;
  // }
  //Percorrendo a area em buscas de itens proximos
  for (int i = x-radius; i <= x+radius; i++){
    for (int j = y-radius; j <= y+radius; j++){
      //Condicional para nao sair dos limites da matrix
      if (i >= 0 && j >= 0 && i < m->rows && j < m->cols && !(i == x && j == y)){
      	if (m->data[i][j] != NULL){
      		float distancia = (1-dist(middle, m->data[i][j])/alpha);
	      	f += distancia;

          if (distancia <= 0)
            return 0;
	      }
      }

    }
  }

  f = f*(1/max*max);

  if (f <= 0)
    return 0;

  return f;
}


//Recebe a formiga na posicao antiga
//Recebe (x, y), posicoes novas
//Deve decidir se a formiga deve pegar o item, que com certeza estara na mesma posicao (x, y)
//Se a formiga pega o item nesta chamada, return TRUE, senao FALSE.
int pegar(Ant *a, int x, int y){
  Matrix  * m = gc->matrix;
  DeadAnt * d = gc->arrayDeadAnt, *n=NULL;
  float chance = 0.0;
  int radius = 1;
  float max = (radius*2 + 1)*(radius*2 + 1);

  //Se a formiga nao esta carregando, entao ha uma change de pegar item
  if(!a->carregando){

    float f = contarEmVolta(x, y, radius, m->data[x][y]);
    
    if (f <= 1.0f){
    	chance = 1;
    }
    else{
    	chance = 1/(f*f);
    }


    //chance = 1 - (cont/max) + 0.01;
    /*
    for (int k = 0; k<gc->numDeadAnt; k++){
      pthread_mutex_lock(&(d[k].mutexDeadAnt));
      if (d[k].i == x && d[k].j == y && !d[k].sendoCarregada){
        contarEmVolta2(x,y,radius,&d[k]);
        n = &(d[k]);
        n->sendoCarregada = 1;
        pthread_mutex_unlock(&(d[k].mutexDeadAnt));
        break;
      }
      pthread_mutex_unlock(&(d[k].mutexDeadAnt));
    }

    if (n != NULL){
        a->corpse = n;
        a->carregando = 1;
        m->data[x][y] = 0;
        return 1;//Formiga esta carregando item a partir de agora.
    }
  }
    */
    if( ( rand() % 100 < chance * 100 )){
      // pegar referencia da formiga no centro (mas ela nao pode ja estar sendo carregada)

      pthread_mutex_lock(&(m->data[x][y]->mutexDeadAnt));
      	m->data[x][y]->sendoCarregada = 1;
      pthread_mutex_unlock(&(m->data[x][y]->mutexDeadAnt));
      a->corpse = m->data[x][y];
      a->carregando = 1;
      m->data[x][y] = NULL;
      return 1;//Formiga esta carregando item a partir de agora.
    }
  }
  return 0; // nao chegou a carregar nada, ou ja estava carregando antes.
}

/*
    Condicionais:

    ->Formiga pode pegar o item e larga-lo no mesmo local
    ->Formiga nao pode largar item em uma posicao que ja exista um item largado
    ->Formiga pode lagar item em cima de outra formiga.

    ->Formula para largar item: (chance = cont/max + 0.01)
*/
int largar(Ant * a, int x, int y){
  Matrix  * m = gc->matrix;
  int radius = 1;
  float chance = 0.0f, max = (radius*2 + 1)*(radius*2+1), f;
  if (a->carregando){
    f = contarEmVolta(x, y, radius, a->corpse);


    if (f >= 1.0f){
    	chance = 1.0f;
    }else{
    	chance = pow(f, 4);
    }

    if (rand() % 100 < chance * 100){
      //Formiga possui referencia à formiga morta: 'corpse'
      pthread_mutex_lock(&(a->corpse->mutexDeadAnt));
      a->corpse->sendoCarregada = 0;
      a->corpse->i = x;
      a->corpse->j = y;
      pthread_mutex_unlock(&(a->corpse->mutexDeadAnt));

      a->corpse->imagem->setPos(a->corpse->imagem, x*gc->width + gc->width/2, y*gc->width + gc->width/2);
      //a->corpse->imagem->setColor(a->corpse->imagem, 1, 1, 1, 1);

      m->data[x][y] = a->corpse;

      a->carregando = 0;
      a->corpse = NULL;
      return 1; // largou item.
    }
  }

  return 0; // continua carregando item
}

///-------------------------------------------------------------------------
//Funcoes e metodos usados nas threads.


void randMoveMethod(Ant * a){
  //srand(time(NULL));
  Matrix * m = gc->matrix;
  int i = 0, j = 0;
  //Escolha uma posicao aleatoria:
  do{
      i = (rand() % 3) - 1;
      j = (rand() % 3) - 1;
    }while(
          !( a->i + i >= 0         &&
             a->i + i <= m->rows-1 &&
             a->j + j >= 0         &&
             a->j + j <= m->cols-1   )
    );

  int oldI = a->i,     oldJ = a->j;
  int newI = a->i + i, newJ = a->j + j;

  //Aqui deve ocorrer bloquamento pois uma formiga nao pode
  //  pegar ou largar itens ao mesmo tempo.

  pthread_mutex_lock(&(m->mutexMatrix));

  if (m->data[newI][newJ] != NULL){
    pegar(a, newI, newJ);
  }else{
    largar(a, newI, newJ);
  }

  pthread_mutex_unlock(&(m->mutexMatrix));

  //Atualizando a posicao da formiga:
  a->i = newI;
  a->j = newJ;

  //Retirei a funcao localmove(), pois fica redundante..
  a->imagem->setPos(a->imagem, newI*gc->width + gc->width/2, newJ*gc->height + gc->height/2);
  if (a->carregando){
    a->corpse->imagem->setPos(a->corpse->imagem, newI*gc->width + gc->width/2, newJ*gc->height + gc->height/2);


    pthread_mutex_lock(&(a->corpse->mutexDeadAnt));
    a->corpse->i = a->i;
    a->corpse->j = a->j;
    pthread_mutex_unlock(&(a->corpse->mutexDeadAnt));
  }
  
}


//Thread de cada formiga que comecara a ser executada assim que elas forem criadas.
void * formigaMainLoop(void * p){
  Ant * a = (Ant *) p;
  if (a == NULL)
    return NULL;

  pthread_barrier_wait(&(gc->barrier));

  while (1){
    	a->randmove(a);
	pthread_mutex_lock(&(gc->mutex_iteracoes));
	if(gc->iteracoes <= 0){
		break;
	}
	gc->iteracoes--;
	pthread_mutex_unlock(&(gc->mutex_iteracoes));
  }
}
