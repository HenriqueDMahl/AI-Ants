#include "ant.h"

/*
	Para compilar isso, computador precisa de:
		Opengl + SDL
				  \-----> Nao é a versao 2.

				  Eu usei a extensao SDL_image. Se Apenas instalar o SDL
				  nao deu certo, tente instalar alguma extensao que possui
				  "SDL_image.h". (so usar apt-get install)

		Nao esqueça de ter o Glut instalado!

	Para compilar: primeira linha do ant.h
*/

/*
	O QUE VOU TENTAR FAZER:

		mudar representacao da matriz:

			ANTES:
				0, 1, 2
			DEPOIS:
				NULL, deadAnt_reference.

		o que isso impacta no programa:
			- formigas poderao nascer uma em cima da outra.
			- se uma deadAnt sobrescrever a outra na matriz ocorre o mesmo problema de antes ao sobreescrever
			- VARIAS.. VARIAS MESMO... operacoes que necessitavam pegar uma formiga em tal posicao da matriz
			  agora ficam mais rapidas.


			- uma das mudancas que fiz: Caso hajam mais formigas mortas que espaços em branco na matriz,
			parte delas nao serao alocadas (DANT > ROWS * COLS).
			QTD que NAO sera Alocada: (DANT - ROWS * COLS)

					- a partir de agora, ao inves de usar a constante DANT, use gc->numDeadAnt, caso, somente,
					vc coloque um valor DANT muuuiiitoo maior que o numero de celulas da matriz. 

					Se nao fizer isso, IGNORE esta mensagem.
			


*/

//Variavel compartilhada entre os arquivos.c
extern Control * gc;

int main(int argc, char ** argv){
	initOpengl(&argc, argv, "Ants");

	//Alocando grupos de imagens
	Group * background = newGroup(),
		  * middle     = newGroup(),
		  * over       = newGroup();

	//Alocando variaveis locais temporarias
	DisplayObj * tmp = NULL;

	//Alocando: MAPA, FORMIGAS (vivas e mortas):
	gc->matrix       = newMatrix(background);
	gc->arrayAnt     = newAnt(middle);
	//gc->arrayDeadAnt = newDeadAnt(middle);
	gc->arrayDeadAnt = loadFromFile(middle, "R15.txt");

	pthread_barrier_wait(&(gc->barrier));
	//Interface legal: (texto + retangulos amarelos)
	DisplayObj *r1, *r2, *t1, *t2;
	r2 = newImage(over, NULL, WIDTH/2, 60);
	r2->img->w = WIDTH*0.6+10;
	r2->img->h = 60;

	r2->img->r = 0.5;
	r2->img->g = 0.5;
	r2->img->b = 0;
	r2->img->a = 0.7;

	r1 = newImage(over, NULL, WIDTH/2, 60);
	r1->img->w = WIDTH*0.6;
	r1->img->h = 50;

	r1->img->r = 0.8;
	r1->img->g = 0.8;
	r1->img->b = 0.4;
	r1->img->a = 0.4;

	t1 = newText(over, "Pressione 'F' para printar matrix no terminal", 160, 55, GLUT_BITMAP_HELVETICA_18);
	t2 = newText(over, "Pressione 'C' para mostrar estatisticas no terminal", 150, 75, GLUT_BITMAP_HELVETICA_18);

	t1->txt->r = 0;
	t1->txt->g = 0;
	t1->txt->b = 0;

	t2->txt->r = 0;
	t2->txt->g = 0;
	t2->txt->b = 0;

    glutMainLoop();

	return 0;
}
