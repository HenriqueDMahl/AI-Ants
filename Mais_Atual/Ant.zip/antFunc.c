#include "ant.h"

//Esse cara aqui (gc) possui referencia para:
//  matrix        : matrix inicializada na main
//  arrayAnt      : vetor de formigas vivas
//  arrayDeadAnt  : vetor de formigas mortas

//  width         : tamanho da celula da matrix (comprimento)
//  height        : tamanho da celula da matrix (altura)
extern Control * gc;

Matrix * newMatrix(Group * g){
  Matrix* matrix = NULL;
  Image * tmp = NULL;

  matrix = (Matrix *) malloc(sizeof(Matrix));
  if (matrix == NULL)
    return NULL;

  //Inserindo constantes
  matrix->rows = ROWS;
  matrix->cols = COLS;

  pthread_mutex_init(&(matrix->mutexMatrix), NULL);

  //Inserindo metodos:
  matrix->get = matrixGet_method;
  matrix->set = matrixSet_method;

  //Inserindo campo 'data':
  DeadAnt** bloco = (DeadAnt **) malloc(sizeof(DeadAnt*)*ROWS*COLS);
  if (bloco == NULL)
    return NULL;

  matrix->data = (DeadAnt ***) malloc(sizeof(DeadAnt**)*ROWS);
  if (matrix->data == NULL)
    return NULL;

  for(int i = 0; i < ROWS; i++) {
      matrix->data[i] = bloco+i*COLS;
      for (int j = 0; j < COLS; j++){
        matrix->data[i][j] = NULL;
        tmp = newImage(g, "matrixBlock.png", i*(gc->width) + gc->width/2, j*(gc->height) + gc->height/2)->img;
        tmp->w = gc->width;
        tmp->h = gc->height;
      }
  }

  tmp = NULL;

  return matrix;
}

Ant * newAnt(Group * g){
  srand(time(NULL));

  Matrix * m = gc->matrix;
  Ant * arrayAnt = (Ant *) malloc(sizeof(Ant) * ANT);
  DisplayObj * im = NULL;


  float width=WIDTH/m->rows, height=HEIGHT/m->cols;
  if (arrayAnt == NULL)
    return NULL;

  int i = 0, j = 0;
  for(int n = 0; n<ANT; n++){
    do{
      i = rand() % m->rows;
      j = rand() % m->cols;
      // garante que nao vai sobrescrever alguma formiga viva ou morta.
      // caso nao hajam mais posicoes != 0, deve sobrescrever para nao causar loop.
      if (!hasFreePosition(0))
        break;
    }while(m->data[i][j] != 0);

    arrayAnt[n].i = i;
    arrayAnt[n].j = j;
    arrayAnt[n].corpse = NULL;
    arrayAnt[n].carregando = 0;
    arrayAnt[n].grupo = 0;

    im = newImage(g, NULL, i, j);
    im->img->w = width*0.8;
    im->img->h = height*0.8;
    im->img->g = 0;
    im->img->b = 0;
    im->img->a = 0;

    im->img->x = floor(i*width) + width/2;
    im->img->y = floor(j*height) + height/2;

    arrayAnt[n].imagem = im;

    arrayAnt[n].randmove = randMoveMethod;

    //é aqui, que o programa vai comecar a bugar :(
    pthread_create(&(arrayAnt[n].thread), NULL, formigaMainLoop, (void *) &(arrayAnt[n]));
    gc->numAnt++;
  }

  m = NULL;
  im = NULL;

  return arrayAnt;
}

int newDeadAnt(Group * g, DeadAnt * d){
  srand(time(NULL));
  Matrix * m = gc->matrix;
  DisplayObj * im = NULL;

  float width=WIDTH/m->rows, height=HEIGHT/m->cols;
  
  if (d == NULL)
    return 0;

  int i = 0, j = 0;
  do{
    i = rand() % m->rows;
    j = rand() % m->cols;

    if (!hasFreePosition())
      return 0;

  }while(m->data[i][j]!=NULL);
  
  d->i = i;
  d->j = j;
  im = newImage(g, NULL, i, j);
  im->img->w = width;//*0.6;
  im->img->h = height;//*0.6;
  
  im->img->x = floor(i*width) + width/2;
  im->img->y = floor(j*height) + height/2;

  d->imagem = im;
  d->sendoCarregada = 0;
  m->data[i][j] = d;

  pthread_mutex_init(&(d->mutexDeadAnt), NULL);
  gc->numDeadAnt++;
  m = NULL;

  return 1;
}

//Verifica se ha alguma posicao 'freeValue' na matriz.
//Se sim, return 1. Caso contrario, return 0.
//Usado para impedir loops na criacao de formigas.
int hasFreePosition(){
  Matrix * m = gc->matrix;
  for (int i = 0; i < m->rows; i++){
    for (int j = 0; j < m->cols; j++){
      if (m->data[i][j]==NULL){
        return 1;
      }
    }
  }
  m = NULL;
  return 0;
}

void matrixSet_method(Matrix * m, DeadAnt * v, int i, int j){
  pthread_mutex_lock(&(m->mutexMatrix));

  if (i >= 0 && i <= m->rows-1 &&
        j >= 0 && j <= m->cols-1)
    m->data[i][j] = v;

  pthread_mutex_unlock(&(m->mutexMatrix));
}

DeadAnt * matrixGet_method(Matrix * m, int i, int j){
  DeadAnt * v = NULL;
  pthread_mutex_lock(&(m->mutexMatrix));

  if (i >= 0 && i <= m->rows-1 &&
      j >= 0 && j <= m->cols-1)
    v = m->data[i][j];

  pthread_mutex_unlock(&(m->mutexMatrix));

  return v;
}

void freeMatrix(){
	for (int i = 0; i < gc->matrix->rows; i++)
		for (int j = 0; j < gc->matrix->cols; j++)
			gc->matrix->data[i][j] = NULL;

  free(gc->matrix->data[0]);
  gc->matrix->data[0] = NULL;
  free(gc->matrix->data);
  gc->matrix->data = NULL;
  free(gc->matrix);
  gc->matrix = NULL;
}

void printMatrix(){
    Matrix * m = gc->matrix;
  	for(int j = 0; j<m->cols; j++){
  		for(int i = 0; i<m->rows; i++){
  			if (m->data[i][j]!=NULL)
  				printf("[x] ");
  			else
  				printf("[ ] ");
  		}
  		printf("\n");
  	}
    m = NULL;
}
